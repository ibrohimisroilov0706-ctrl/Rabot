// apps/client/src/env.d.ts
declare module '*.css';
interface ImportMetaEnv { readonly VITE_API_URL?: string }
interface ImportMeta { readonly env: ImportMetaEnv }
