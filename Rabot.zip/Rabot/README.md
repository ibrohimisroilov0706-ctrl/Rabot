# Rabot

Three.js asosidagi 3D virtual planeta, birinchi prototip. Backend ham, build ham kerak emas, oddiy statik sayt.

## Fayl tuzilmasi

```
Rabot/
├── index.html
├── .nojekyll
├── README.md
├── css/
│   └── style.css
└── js/
    ├── main.js      (sahna, kamera, boshqaruv, interfeys)
    ├── planet.js    (planeta, bulutlar, atmosfera, yulduzlar)
    ├── markers.js   (hudud belgilari)
    ├── regions.js   (hududlar ro'yxati)
    └── noise.js     (relyef uchun shovqin funksiyasi)
```

## Lokal ishga tushirish

ES modullar `file://` orqali ishlamaydi, oddiy server kerak:

```bash
python3 -m http.server 8000
# keyin brauzerda: http://localhost:8000
```

(Yoki VS Code'da "Live Server" kengaytmasi.)

## GitHub Pages

1. Barcha fayllarni repozitoriy ildiziga yuklang (`main` branch).
2. Settings, Pages bo'limiga kiring.
3. Source: "Deploy from a branch", Branch: `main`, papka: `/ (root)`.
4. Saqlang. 1-2 daqiqadan keyin sayt `https://ibrohimisroilov0706-ctrl.github.io/Rabot/` manzilida ochiladi.

## Vercel

1. vercel.com ichida "Add New, Project" tanlang va `Rabot` repozitoriyasini ulang.
2. Framework Preset: **Other**. Build Command va Output Directory bo'sh qoladi.
3. Deploy bosing.

## Yangi hudud qo'shish

`js/regions.js` ichidagi `REGIONS` ro'yxatiga yangi obyekt qo'shing. Planeta relyefi, belgi, yorliq va pastdagi tugma avtomatik paydo bo'ladi.
